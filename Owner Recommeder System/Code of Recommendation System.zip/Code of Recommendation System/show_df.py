import sys
import pandas as pd
from PyQt5.QtWidgets import QApplication, QTableView
from PyQt5.QtCore import QAbstractTableModel, Qt

from PyQt5 import QtCore, QtGui, QtWidgets

df = pd.DataFrame({'a': [i for i in range(100)],
                   'b': [i+100 for i in range(100)],
                   'c': [i*2 for i in range(100)]})

class pandasModel(QAbstractTableModel):

    def __init__(self, data):
        QAbstractTableModel.__init__(self)
        self._data = data

    def rowCount(self, parent=None):
        return self._data.shape[0]

    def columnCount(self, parnet=None):
        return self._data.shape[1]

    def data(self, index, role=Qt.DisplayRole):
        if index.isValid():
            if role == Qt.DisplayRole:
                return str(self._data.iloc[index.row(), index.column()])
        return None

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self._data.columns[col]
        return None
    
'''
if __name__ == '__main__':
    app = QApplication(sys.argv)
    model = pandasModel(df)
    view = QTableView()
    view.setModel(model)
    view.resize(800, 600)
    view.show()
    sys.exit(app.exec_())
  '''  
  
    
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    OtherWindow = QtWidgets.DesignMy()
    ui = pandasModel(df)
    ui.setupUi(OtherWindow)
    
    view = QTableView()
    view.setModel(ui)
    view.resize(800, 600)
    view.show()
    OtherWindow.show()
    sys.exit(app.exec_())
