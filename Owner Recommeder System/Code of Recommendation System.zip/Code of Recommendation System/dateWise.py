
import os
import pandas as pd
import numpy as np

def load_dateWise(df_TR,d,m,y):
    
    df_TR['DATE']  = [i.split(' ')[0] for i in df_TR.Date ]
    
    
    #date = '12/1/2010'
    date = m+'/'+d+'/'+y
    
    df_Sessional = df_TR[df_TR.DATE == date]
    
    return df_Sessional

