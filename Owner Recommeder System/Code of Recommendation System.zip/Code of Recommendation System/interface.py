import sys

from PyQt5 import QtCore, QtGui, QtWidgets

from PyQt5.QtCore import pyqtSlot,QAbstractTableModel, Qt
from PyQt5.QtWidgets import QApplication , QDialog, QWidget, QInputDialog, QLineEdit, QFileDialog,QTableView
from PyQt5.uic import loadUi
from load_data import load_
import pandas as pd
import numpy as np
import itertools
import collections as c

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules
#from monthly import load_month
#from dateWise import load_dateWise
import pandas as pd
import os

#from Full_file_run import *


def load_my():
    return pd.read_csv('trasactional_db.csv')
    
df_TR = load_my()

df_TR['DATE']  = [i.split(' ')[0] for i in df_TR.Date ]
df_TR['M_Y']  = ['/'.join(i.split(' ')[0].split('/')[::2]) for i in df_TR.Date ]
dic_month_num_alph = {1:'Jan', 2:'Feb', 3:'March', 4:'April', 5:'May', 6:'June', 7:'July', 8:'Aug', 9:'Sep', 10:'Nov', 11:'Oct', 12:'Dec'}
df_TR['Month_Name'] = [dic_month_num_alph[int( dt.split('/')[0] )] for dt in df_TR.M_Y]

new = []
for i in df_TR.Month_Name:
    if i =='Nov' or i == 'Dec' or i == 'Jan':
        new.append('Winter')
    elif i =='May' or i == 'Jun' or i == 'July':
        new.append('Summer')
    else:
        new.append(i)
df_TR['Season_name'] = new


df = pd.read_csv('Binary_DB.csv')

dic = dict()
for i in df.columns[0:]:
    dic[i]  = df[i].sum()

d_d = pd.DataFrame((list(dic.values())) , columns= ["Support"], index=[list(dic.keys())])
d_d['items'] = list(d_d.index)
d_d_top = d_d[d_d.Support == sorted(d_d.Support)[-1]]

d_d_low = d_d[d_d.Support == sorted(d_d.Support)[0]]

dfx = df.loc[:5000]
frequent_itemsets_ = apriori(dfx, min_support=0.02, use_colnames=True)
frequent_itemsets_['length'] = frequent_itemsets_['itemsets'].apply(lambda x: len(x))
frequent_itemsets_ = frequent_itemsets_.sort_values('support',ascending=False)

max_sprt = max(frequent_itemsets_.support)

rules_ = association_rules(frequent_itemsets_, metric="confidence", min_threshold=0.01)

for_person = rules_[rules_.columns[:2]]

class DesignMy(QDialog):
    
        
    def __init__(self):
        super(DesignMy,self).__init__()
        loadUi('myy.ui',self)
        
        self.Data = None
        self.df_Sessional_M = None
        self.df_Sessional = None
        
        self.setWindowTitle('Pyqt5 Window')
        self.pushButton.clicked.connect(self.on_pushButton_clicked)
        self.monthButton.clicked.connect(self.on_monthButton_clicked)
        self.dateButton.clicked.connect(self.on_dateButton_clicked)
        self.lowItemButton.clicked.connect(self.on_lowItemButton_clicked)
        self.highItemButton.clicked.connect(self.on_highItemButton_clicked)
        #self.itemForSaleBtn.clicked.connect(self.on_itemForSaleBtn_clicked)
        
        self.d_d_topButton.clicked.connect(self.on_d_d_topButton_clicked)
        self.d_d_lowButton.clicked.connect(self.on_d_d_lowButton_clicked)
        
        self.spcialevntShowBtn.clicked.connect(self.on_spcialevntShowBtn_clicked)
        
        self.summerBtn.clicked.connect(self.on_summerBtn_clicked)
        self.winterBtn.clicked.connect(self.on_winterBtn_clicked)
        
        self.frequentButton.clicked.connect(self.on_frequentButton_clicked)
        self.ruleButton.clicked.connect(self.on_ruleButton_clicked)
        self.for_person_ruleButton.clicked.connect(self.on_for_person_ruleButton_clicked)
        
    @pyqtSlot()
    def on_pushButton_clicked(self):
        #self.label2.setText('Welcome : '+self.lineEdit.text())
        #self.openFileNameDialog()
        
        self.main_label.setText('data not loaded')
        load_my()
        self.main_label.setText('ready to run')
    @pyqtSlot()
    def on_monthButton_clicked(self):
        m = self.lineEdit_2.text()
        y = self.lineEdit_3.text()
        #x = load_month(self.Data,m,y)
        #print(df_Sessional_M)
        #sessional_Month = month_wise()
        datex = str(m+'/'+y)
        self.df_Sessional_M = df_TR[df_TR.M_Y == datex]
        print(self.df_Sessional_M)
        self.run(self.df_Sessional_M,'Report Month')
        #self.lineEdit_2.clear()
        print('done------------------')

    @pyqtSlot()
    def on_dateButton_clicked(self):
        d = self.lineEdit_6.text()
        m = self.lineEdit_5.text()
        y = self.lineEdit_4.text()
        #x = load_dateWise(self.Data,d,m,y)
        #sessional_Daywise = date_wise(d,m,y)
        
        date = str(m+'/'+d+'/'+y)

        self.df_Sessional = df_TR[df_TR.DATE == date]
        print(self.df_Sessional)
        self.run(self.df_Sessional,'Report Date')
        print('done------------------')
    
    def low_item(self):
        sessional_lis = c.Counter([ j for i in self.df_Sessional.Items for j in i.split(',')])
        sessional_lis_result = sorted(list(sessional_lis.items()),key=lambda x: x[1],reverse=True)

        code_sess_lis = [i[0] for i in sessional_lis_result]
        code_sess_num_lis = [i[1] for i in sessional_lis_result]

        df_sessional_itemCode = pd.DataFrame(columns=['Items','count'])
        df_sessional_itemCode['Items'] = code_sess_lis
        df_sessional_itemCode['count'] = code_sess_num_lis  
        return df_sessional_itemCode
    
    @pyqtSlot()
    def on_lowItemButton_clicked(self):
        
        x = self.low_item()
        #less_demand_low = less_demand_item()
        #print(less_demand_low)
        self.run(x,'Report low ')
        print('done------------------')
        
    @pyqtSlot()
    def on_highItemButton_clicked(self):
        sessional_lis_M = c.Counter([ j for i in self.df_Sessional_M.Items for j in i.split(',')])
        sessional_lis_result_M = sorted(list(sessional_lis_M.items()),key=lambda x: x[1],reverse=True)

        code_sess_lis_M = [i[0] for i in sessional_lis_result_M]
        code_sess_num_lis_M = [i[1] for i in sessional_lis_result_M]

        df_sessional_itemCode_M = pd.DataFrame(columns=['Items','count'])
        df_sessional_itemCode_M['Items'] = code_sess_lis_M
        df_sessional_itemCode_M['count'] = code_sess_num_lis_M
        #high_demand_high = high_demand_item()
        self.run(df_sessional_itemCode_M,'Report')
        print('done------------------')
        
    @pyqtSlot()
    def on_itemForSaleBtn_clicked(self):

        #x = low_item()
        #xx = x[x.count < 2]
        #self.run(xx,'Report')
        print('done------------------')   
        
    @pyqtSlot()
    def on_d_d_topButton_clicked(self):


        self.run(d_d_top,'Report')
        print('done------------------')

    @pyqtSlot()
    def on_d_d_lowButton_clicked(self):


        self.run(d_d_low,'Report')
        print('done------------------')

    @pyqtSlot()
    def on_spcialevntShowBtn_clicked(self):
        d = self.dBtn.text()
        m = self.mBtn.text()
        y = self.yBtn.text()
        #x = load_dateWise(self.Data,d,m,y)
        #sessional_Daywise = date_wise(d,m,y)
        
        date = str(m+'/'+d+'/'+y)

        df_SessionalNew = df_TR[df_TR.DATE == date]
        print(df_SessionalNew)
        self.run(df_SessionalNew,'Report sessioanl')
        print('done------------------')


    @pyqtSlot()
    def on_summerBtn_clicked(self):
        winter_df = df_TR[df_TR.Season_name == 'Winter']

        winter_lis_M = c.Counter([ j for i in winter_df.Items for j in i.split(',')])
        winter_lis_result_M = sorted(list(winter_lis_M.items()),key=lambda x: x[1],reverse=True)

        code_winter_lis_M = [i[0] for i in winter_lis_result_M]
        code_winter_num_lis_M = [i[1] for i in winter_lis_result_M]


        df_winter_itemCode_M = pd.DataFrame(columns=['Items','count'])
        df_winter_itemCode_M['Items'] = code_winter_lis_M
        df_winter_itemCode_M['count'] = code_winter_num_lis_M       
        #high_demand_high = high_demand_item()
        self.run(df_winter_itemCode_M,'Report')
        print('done------------------')
        
        
    @pyqtSlot()
    def on_winterBtn_clicked(self):
        summer_df = df_TR[df_TR.Season_name == 'Summer']

        summer_lis_M = c.Counter([ j for i in summer_df.Items for j in i.split(',')])
        summer_lis_result_M = sorted(list(summer_lis_M.items()),key=lambda x: x[1],reverse=True)

        code_summer_lis_M = [i[0] for i in summer_lis_result_M]
        code_summer_num_lis_M = [i[1] for i in summer_lis_result_M]


        df_summer_itemCode_M = pd.DataFrame(columns=['Items','count'])
        df_summer_itemCode_M['Items'] = code_summer_lis_M
        df_summer_itemCode_M['count'] = code_summer_num_lis_M
        #high_demand_high = high_demand_item()
        self.run(df_summer_itemCode_M,'Report')
        print('done------------------')
        
        
    @pyqtSlot()
    def on_frequentButton_clicked(self):


        self.run(frequent_itemsets_,'Report')
        print('done------------------')
        
    @pyqtSlot()
    def on_ruleButton_clicked(self):


        self.run(rules_,'Report')
        print('done------------------')

    @pyqtSlot()
    def on_for_person_ruleButton_clicked(self):


        self.run(for_person,'Report')
        print('done------------------')



                         
    def run(self,data,outFile):
        outFile = outFile + '.html'
        pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>

        html_string = '''
        <html>
          <head><title>HTML Pandas Dataframe with CSS</title></head>
          <link rel="stylesheet" type="text/css" href="df_style.css"/>
          <body>
            {table}
          </body>
        </html>.
        '''

        # OUTPUT AN HTML FILE
        with open(outFile, 'w') as f:
            f.write(html_string.format(table=data.to_html(classes='mystyle',index=False)))

        os.startfile(outFile)
        
    def openFileNameDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName, _ = QFileDialog.getOpenFileName(self,"QFileDialog.getOpenFileName()", "","Files (*.csv)", options=options)
        if fileName:
            print(fileName)
            self.label2.setText('Path : '+fileName)
            self.Data = load_(fileName)
            print(self.Data.shape)

    
    


def get_monthYear():

    return m,y

def month_wise():

    obj = DesignMy()
    m= obj.lineEdit_2.text()
    y= obj.lineEdit_3.text()
    print('11111111111111')
    
    datex = str(m+'/'+y)
    print(datex)
    print('222222222222222222')
    #datex = '12/2010'

    
def date_wise(d,m,y):

    date = str(m+'/'+d+'/'+y)
    datee = date
    #date = '12/1/2010'


def less_demand_item():#as#
    obj = DesignMy()
    
    sessional_lis = c.Counter([ j for i in obj.df_Sessional.Items for j in i.split(',')])
    sessional_lis_result = sorted(list(sessional_lis.items()),key=lambda x: x[1],reverse=True)

    code_sess_lis = [i[0] for i in sessional_lis_result]
    code_sess_num_lis = [i[1] for i in sessional_lis_result]

    df_sessional_itemCode = pd.DataFrame(columns=['Items','count'])
    df_sessional_itemCode['Items'] = code_sess_lis
    df_sessional_itemCode['count'] = code_sess_num_lis
    return df_sessional_itemCode

def high_demand_item():#as#
    obj = DesignMy()
    sessional_lis_M = c.Counter([ j for i in obj.df_Sessional_M.Items for j in i.split(',')])
    sessional_lis_result_M = sorted(list(sessional_lis_M.items()),key=lambda x: x[1],reverse=True)

    code_sess_lis_M = [i[0] for i in sessional_lis_result_M]
    code_sess_num_lis_M = [i[1] for i in sessional_lis_result_M]

    df_sessional_itemCode_M = pd.DataFrame(columns=['Items','count'])
    df_sessional_itemCode_M['Items'] = code_sess_lis_M
    df_sessional_itemCode_M['count'] = code_sess_num_lis_M
    return df_sessional_itemCode_M

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = DesignMy()
    #ui.setupUi(MainWindow)
    ui.show()
    sys.exit(app.exec_())
