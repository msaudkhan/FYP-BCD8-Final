﻿function Update () {
	if(Input.GetButtonDown("Fire1")) {
		var gunsound : AudioSource = GetComponent.<AudioSource>();
		gunsound.Play();
		GetComponent.<Animation>().Play("mp5anim");
		GlobalAmmo.CurrentAmmo -= 1;
	}
}

