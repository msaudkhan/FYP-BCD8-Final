﻿function Update () {
	if(Input.GetButtonDown("Fire1")) {
	GlobalAmmo.CurrentAmmo -= 1;
		var gunsound : AudioSource = GetComponent.<AudioSource>();
		gunsound.Play();
		GetComponent.<Animation>().Play("Gunshot");
	}
}

