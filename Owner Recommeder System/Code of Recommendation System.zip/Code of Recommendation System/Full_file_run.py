import pandas as pd
import numpy as np
import itertools
import collections as c

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

df_TR = pd.read_csv('trasactional_db.csv')


df_TR['DATE']  = [i.split(' ')[0] for i in df_TR.Date ]
df_TR['M_Y']  = ['/'.join(i.split(' ')[0].split('/')[::2]) for i in df_TR.Date ]


df_TRR = df_TR

datex = '12/2010'
df_Sessional_M = df_TR[df_TR.M_Y == datex]

date = '12/1/2010'
df_Sessional = df_TR[df_TR.DATE == date]

sessional_lis = c.Counter([ j for i in df_Sessional.Items for j in i.split(',')])
sessional_lis_result = sorted(list(sessional_lis.items()),key=lambda x: x[1],reverse=True)

code_sess_lis = [i[0] for i in sessional_lis_result]
code_sess_num_lis = [i[1] for i in sessional_lis_result]

df_sessional_itemCode = pd.DataFrame(columns=['Items','count'])
df_sessional_itemCode['Items'] = code_sess_lis
df_sessional_itemCode['count'] = code_sess_num_lis


sessional_lis_M = c.Counter([ j for i in df_Sessional_M.Items for j in i.split(',')])
sessional_lis_result_M = sorted(list(sessional_lis_M.items()),key=lambda x: x[1],reverse=True)

code_sess_lis_M = [i[0] for i in sessional_lis_result_M]
code_sess_num_lis_M = [i[1] for i in sessional_lis_result_M]

df_sessional_itemCode_M = pd.DataFrame(columns=['Items','count'])
df_sessional_itemCode_M['Items'] = code_sess_lis_M
df_sessional_itemCode_M['count'] = code_sess_num_lis_M

df = pd.read_csv('Binary_DB.csv')

dic = dict()
for i in df.columns[0:]:
    dic[i]  = df[i].sum()

d_d = pd.DataFrame((list(dic.values())) , columns= ["Support"], index=[list(dic.keys())])

d_d_top = d_d[d_d.Support == sorted(d_d.Support)[-1]]

d_d_low = d_d[d_d.Support == sorted(d_d.Support)[0]]
dfx = df.loc[:5000]
frequent_itemsets_ = apriori(dfx, min_support=0.02, use_colnames=True)
frequent_itemsets_['length'] = frequent_itemsets_['itemsets'].apply(lambda x: len(x))
frequent_itemsets_ = frequent_itemsets_.sort_values('support',ascending=False)

max_sprt = max(frequent_itemsets_.support)

rules_ = association_rules(frequent_itemsets_, metric="confidence", min_threshold=0.01)

for_person = rules_[rules_.columns[:2]]



