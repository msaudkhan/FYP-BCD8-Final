
import os
import pandas as pd
import numpy as np

def load_month(df_TR,m,y):
    
    df_TR['DATE']  = [i.split(' ')[0] for i in df_TR.Date ]
    df_TR['M_Y']  = ['/'.join(i.split(' ')[0].split('/')[::2]) for i in df_TR.Date ]
    
    #datex = '12/2010'
    datex = m+'/'+y
    
    df_Sessional_M = df_TR[df_TR.M_Y == datex]
    
    return df_Sessional_M

