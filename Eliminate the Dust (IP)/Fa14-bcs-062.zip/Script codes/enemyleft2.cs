﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class enemyleft2 : MonoBehaviour {
	public static int leftvalue = 90;
	public GameObject door;
	Text left;
	// Use this for initialization
	void Start () {
		left = GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		left.text = "Zombies: " + leftvalue;
		if (leftvalue == 0) {
			SceneManager.LoadScene (0);
		}
		}
	}


