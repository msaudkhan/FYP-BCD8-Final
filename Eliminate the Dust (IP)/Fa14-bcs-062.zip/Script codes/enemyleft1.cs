﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class enemyleft1 : MonoBehaviour {
	public static int leftvalue = 72;
	Text left;
	// Use this for initialization
	void Start () {
		left = GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		left.text = "Zombies: " + leftvalue;
		if (leftvalue == 0) {
			Application.LoadLevel (3);
		}

	}

}
